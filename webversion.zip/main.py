import pygame
import sys
import textwrap
import random
import asyncio

count = 0
cursor_bool = True
async def main():
    global cursor_bool
    global count
    # Inizializzazione di Pygame
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load('music.mp3')
    pygame.mixer.music.set_volume(0.5) 
    pygame.mixer.music.play(-1)
    def cursor(time):
        global cursor_bool
        global count
        if cursor_bool:
            count += 1
        else:
            count -= 1   
        if count >= time:
            cursor_bool = False
        elif count <= -time:
            cursor_bool = True
        if count > 0:
            return  "|"
        elif count < 0:
            return  ""


    # Dimensioni della finestra
    larghezza, altezza = 800, 600

    # Creazione della finestra
    schermo = pygame.display.set_mode((larghezza, altezza))

    # Carica un'immagine

    immagine1 = pygame.image.load('Image1.jpg')
    immagine1 = pygame.transform.scale(immagine1, (400, 400))  # Ridimensiona l'immagine se necessario
    immagine2 = pygame.image.load('Image2.jpg')
    immagine2 = pygame.transform.scale(immagine2,(400,400))
    immagine3 = pygame.image.load('Image3.jpg')
    immagine3 = pygame.transform.scale(immagine3,(400,400))
    immagine4 = pygame.image.load('Image7.jpg')
    immagine4 = pygame.transform.scale(immagine4,(400,400))
    immagine5 = pygame.image.load('Image8.jpg')
    immagine5 = pygame.transform.scale(immagine5,(400,400))
    immagine6 = pygame.image.load('Image4.jpg')
    immagine6 = pygame.transform.scale(immagine6,(400,400))
    immagine7 = pygame.image.load('Image5.jpg')
    immagine7 = pygame.transform.scale(immagine7,(400,400))
    immagine8 = pygame.image.load('Image9.jpg')
    immagine8 = pygame.transform.scale(immagine8,(400,400))

    # Definisci i colori
    nero = (40, 40, 40)
    bianco = (255, 255, 255)
    verde = (0,255,102)
    # Font per il testo
    font = pygame.font.Font(None, 20)

    # Testo di esempio
    testo = "You are a brave astronaut, part of a daring exploration mission to an unknown planet. While you are in a state of suspension in the cryogenic capsule during the journey, the alarm system suddenly activates. The cryo-capsule deactivates, waking you up hastily. Looking around, you realize with terror that the rest of the crew has somehow been lost, and you are the only survivor. Your capsule is plummeting toward a completely dark planet, a place that seems to capture and obscure the light. press Enter to continue"
    position = 'wreckage'
    decision = 'None'
    flashlight = False
    insectlight = False
    prologue = "You decide to explore the immediate surroundings in the shuttle wreckage. Broken pieces of the shuttle are scattered around you, and it's eerily quiet. As you look around, you spot a corridor leading to the west and another passage going south. The westward corridor seems more intact, but it's still quite dark. What would you like to do next?"
    death = 'You decide to head south, but as you venture further into the darkness without any source of light, you quickly become disoriented, and the darkness becomes suffocating. Suddenly, you stumble and fall, unable to see anything. In the pitch-black darkness, you lose your way completely, and your journey comes to an abrupt and unfortunate end. It seems you\'ve met an untimely demise.'
    west_corridor = 'You turn your attention to the westward corridor. With a careful step, you enter the corridor and find yourself in a dimly lit section of the wreckage. Broken equipment and scattered debris surround you. As you explore, you discover a small compartment on the wall'
    compartment = 'Inside the compartment, you find a pair of batteries, a small hammer and a bottle. Do you want to pick them?'
    items = 'you picked the items, what do you want to do now?'
    picknot = 'you didn\'t pick the items. What do you want to do next?'
    question = 'What do you want to do next?'
    hangar = 'Thanks to the flashlight you arrived safe in the hangar. You saw some creeping and disturbing creatures in the dark'
    transmittent_part = 'The transmittent is your last chance to send a message to the earth. It\'s vital to repair the device. ' + \
                        'While you wonder how you can do it, you spot a glowing cavern to the north of the wreckage. ' + \
                        'The flashlight won\'t last long, you better find a solution soon '

    cavern_part = 'You decide to head in the direction of the cave. You carefully retrace your steps through the wreckage and make your way to the entrance of the cave. As you enter, the darkness within is overwhelming, and your flashlight batteries won\'t last long. ' + \
                    'However, as you venture deeper into the cave, you start to notice a faint, ethereal glow. It leads you further in, ' + \
                    'and you discover a hidden underground area bathed in a soft, bluish light. The source of the light becomes clear when you spot a ' + \
                    'colony of glowing insects fluttering around. '
    risposta = '>> '
    immagine = immagine1
    item = []
    start = True
    x = 8

    time = 10
    curs = '|'
    light_batt = False
    import math

    while True:
        
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                await asyncio.sleep(0)
                pygame.quit()
                sys.exit()
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                elif evento.key == pygame.K_RETURN:
                    # Esegui azione con il testo inserito
                    if start:
                        #print("Testo inserito:", testo)
                        testo = prologue
                    start = False
                    #rileva la risposta del giocatore
                    if 'south' in risposta.lower():
                        decision = 'south'
                                      
                    elif 'west' in risposta.lower():
                        decision = 'west'

                    elif 'east' in risposta.lower():
                        decision = 'east'

                    elif 'north' in risposta.lower():
                        decision = 'north'
                        
                    elif 'examine' in risposta.lower() or 'look' in risposta.lower() \
                         or 'inspect' in risposta.lower() or 'investigate' in risposta.lower()\
                         or 'explore' in risposta.lower():
                        decision = 'inspect'
                        
                    elif 'yes' in risposta.lower():
                        decision = 'yes'
                        
                    elif 'pick' in risposta.lower() or 'take' in risposta.lower() or \
                         'get' in risposta.lower():
                        decision = 'pick'
                        
                    elif 'no' in risposta.lower():
                        decision = 'no'
                        
                    elif 'use' in risposta.lower() or 'combine' in risposta.lower():
                        if 'batteries' in risposta.lower():
                            if 'flashlight' in risposta.lower() and 'flashlight' in item:
                                decision = 'use batteries on flashlight'
                            else:
                                decision = 'on what?'
                        elif 'bottle' in risposta.lower():
                            decision = 'use bottle'
                            
                        elif 'hammer' in risposta.lower():
                            decision = 'use hammer'
                        elif 'crystal' in risposta.lower():
                            decision = 'use crystal'
                    
                    elif 'turn on' in risposta.lower() and 'flashlight' in risposta.lower():
                        decision = 'turn on flashlight'
                                
                    elif 'items' in risposta.lower():
                        decision = 'check items'

                    

                        
                            
                    else:
                        pass
                    
                    risposta = '>> ' 
                #definisci la nuova posizione e azione sulla base della posizione corrente
                if decision == 'south':
                    if flashlight == False and insectlight == False and position == 'wreckage':
                        testo = death
                        immagine = immagine3
                    elif flashlight == True or insectlight == True and position == 'wreckage':
                        testo = hangar
                        immagine = immagine5
                        position = 'hangar'

                elif decision == 'north':
                    if position == 'hangar':
                        testo = 'You are in the wreckage of the shuttle. ' + question
                        immagine = immagine1
                        position = 'wreckage'
                        decision = ''
                    elif position == 'wreckage' and flashlight == True:
                        position = 'cavern'
                        immagine = immagine6
                        testo = cavern_part + question
                    elif position == 'wreckage' and flashlight == False:
                        testo = 'it\'s too dark to head that way! ' + question
                    
                    
                elif position == 'wreckage' and decision == 'west':
                    testo = west_corridor
                    immagine = immagine2
                    position = 'corridor'
                    
                elif position == 'corridor' and decision == 'inspect':
                    immagine = immagine4
                    testo = compartment
                    position = 'compartment'
                    
                elif position == 'compartment' and (decision == 'yes' or decision == 'pick'):
                    testo = items
                    if ('hammer' and 'batteries' and 'bottle') not in item:
                        item.append('hammer')
                        item.append('batteries')
                        item.append('bottle')

                elif decision == 'pick' and position == 'crystal_chamber':
                    testo = 'It is to big to be transported. '

            
                    
                elif decision == 'inspect':
                    if position == 'wreckage':
                        testo = 'you found a flashlight! what do you want to do next?'
                        if 'flashlight' not in item:
                            item.append('flashlight') 
                    elif position == 'hangar':
                        testo = 'ther\'s a broken compartment. It does\'nt open'
                    elif position == 'cavern':
                        testo = 'Ther\'s a small passage to the east. '
                        

                elif decision == 'use hammer':
                    if position == 'hangar':
                        testo = 'The compartment now is open. You found a broken transmittent. ' + transmittent_part + question
                        if 'transmittent' not in item:
                            item.append('transmittent')
                    elif position == 'crystal_chamber':
                        testo = 'you break a piece of the crystal. It looks like it has piezoelectric properties...'
                        if 'crystal' not in item:
                            item.append('crystal')
                            
                elif decision == 'use crystal':
                    if 'transmittent' in item:
                        testo = 'Now you can use transmittent! You send a message to the earth! ' + \
                                'I hope you had fun, thanks for playing!'
                    else:
                        testo = 'You can use it in that way. ' + question

                elif decision == 'use bottle':
                    if position == 'cavern':
                        testo = 'You put insects into the bottle, now you have another source of light! Just in time! '+ \
                                'The flashlight is out of use. You can continue exploring the cave. ' + question
                        insectlight = True
                        immagine = immagine7
                        flashlight = False                    
                    
                elif position == 'compartment' and decision == 'no':
                    testo = picknot
                    
                elif decision == 'use batteries on flashlight':
                    light_batt = True
                    testo = 'now you can use the flashlight'
                    
                    
                elif decision == 'no flash':
                    testo = 'You don\'t have the flashlight. ' + question
                    
                elif (position == 'compartment' or position =='corridor') and decision == 'east':
                    testo = 'You are in the wreckage of the shuttle, ' + question
                    immagine = immagine1
                    position = 'wreckage'

                elif decision == 'east' and position == 'cavern':
                    testo = 'In front of you, you see a big crystal. ' + question
                    immagine = immagine8
                    position = 'crystal_chamber'

                
                elif decision == 'on what':
                    testo = 'on what'

                elif decision == 'turn on flashlight':
                    if light_batt:
                        flashlight = True
                        testo = 'flashlight is now on. ' + question
                    else:
                        testo = 'flashlight needs battery. ' + question

                elif decision == 'check items':
                    testo = ''
                    testo = ' | '.join(str(item[i]) for i in range(len(item)))
                    #print(testo)
                    if testo == '':
                        testo = 'no items. ' + question

            
                
                    
                    
                    
                    
                    
                            
                #delete   
                if evento.key == pygame.K_BACKSPACE:
                    risposta = risposta[:-1]
                else:
                    risposta += evento.unicode
        

        # Pulisci lo schermo
        schermo.fill(nero)

        # Disegna l'immagine
        schermo.blit(immagine, (0, 0))

        # Disegna la parte della console
        pygame.draw.rect(schermo, nero, (400, 0, 400, 600))
        lines = textwrap.wrap(testo, 60)  # Imposta una larghezza massima per le righe
        lines2 = textwrap.wrap(risposta,400)
        y = 10
        y2 = 450
        for line in lines:
            text_surface = font.render(line, True, verde)  # Imposta il colore su bianco
            schermo.blit(text_surface, (410, y))
            y += 30
            
        for line in lines2:
            text_surface2 = font.render(line, True, verde)
            schermo.blit(text_surface2, (15, y2))
            y2 += 30
            
        #blinking cursor
        input_width = font.size(risposta)[0]
        text_surface3 = font.render(cursor(200),True,verde)
        schermo.blit(text_surface3, (x + input_width + 8,y2-30))
        pygame.display.update()
        #print('decision: ', decision,'\n', 'position: ', position)


asyncio.run(main())

        
